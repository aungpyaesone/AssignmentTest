package com.example.assignmenttest.activity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.os.Bundle;
import com.example.assignmenttest.R;
import com.example.assignmenttest.adapter.MyAdapter;
import com.example.assignmenttest.data.CurrencyResponse;
import com.example.assignmenttest.data.Rates;
import com.example.assignmenttest.data.model.CurrencyModel;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;


public class MainActivity extends BaseActivity {

    @BindView(R.id.recycler)
    RecyclerView recyclerView;

    private List<CurrencyResponse> currencyResponses;
    private List<Rates>  ratesList;
    private MyAdapter adapter;
    private CurrencyModel model;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this,this);
        init();
        setUpRecycler();
    }

    private void init() {
        currencyResponses = new ArrayList<>();
        ratesList = new ArrayList<>();
        model = CurrencyModel.getObjInstance();
    }

    private void setUpRecycler() {
        adapter = new MyAdapter();
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

    }

    @Override
    protected void onResume() {
        currencyResponses.clear();
        isFetch();
        super.onResume();
    }

    private void isFetch() {
        model.getData();
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void loadData(CurrencyResponse response) {
        ratesList.clear();
        ratesList.addAll(response.getRates());
        adapter.bindData(ratesList);

        CurrencyResponse stickyEvent = EventBus.getDefault().getStickyEvent(CurrencyResponse.class);
        if(stickyEvent != null)
        {
            EventBus.getDefault().removeStickyEvent(stickyEvent);
        }
    }

}
