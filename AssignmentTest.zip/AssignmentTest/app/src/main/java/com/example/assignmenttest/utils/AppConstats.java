package com.example.assignmenttest.utils;

public class AppConstats {
    public static final String BASE_URL = "https://forex.cbm.gov.mm/api/";

}
