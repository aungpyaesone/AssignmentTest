package com.example.assignmenttest.network;

public interface DataAgent {

     void getData();
}
